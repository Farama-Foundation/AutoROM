Due to a legal issue, Atari ROM files are no longer installed by default with the Gym library (or more specifically ALE-Py, which Gym depends on).

AutoROM automatically installs the needed Atari ROMs into the ALE-Py folder in a very simple manner:

```
pip3 install autorom
AutoROM
```
